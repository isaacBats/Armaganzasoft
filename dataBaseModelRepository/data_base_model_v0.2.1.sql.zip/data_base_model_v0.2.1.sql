
-- lun 29 feb 2016 22:55:25 CST
-- Model: Data Base Armaganza    Version: 0.2.1
-- Author Isaac Daniel Batista

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema armaganza
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `armaganza` ;

-- -----------------------------------------------------
-- Schema armaganza
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `armaganza` DEFAULT CHARACTER SET utf8 ;
USE `armaganza` ;

-- -----------------------------------------------------
-- Table `armaganza`.`branches`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`branches` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`branches` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(140) NOT NULL,
  `adress` VARCHAR(140) NULL,
  `telephone` VARCHAR(15) NOT NULL,
  `city` VARCHAR(140) NULL,
  `zip_code` VARCHAR(10) NOT NULL,
  `rfc` VARCHAR(25) NOT NULL,
  `email` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`users` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `branch_id` INT NOT NULL,
  `num_employee` VARCHAR(45) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(80) NULL,
  `email` VARCHAR(80) NOT NULL,
  `password` VARCHAR(40) NOT NULL,
  `position` VARCHAR(45) NULL,
  `roll` VARCHAR(45) NULL,
  `active` TINYINT(1) NULL,
  `update_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `branch_id_idx` (`branch_id` ASC),
  CONSTRAINT `branch_id`
    FOREIGN KEY (`branch_id`)
    REFERENCES `armaganza`.`branches` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`customers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`customers` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`customers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identified` VARCHAR(15) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(80) NULL,
  `email` VARCHAR(80) NOT NULL,
  `telephone` VARCHAR(15) NOT NULL,
  `movil` VARCHAR(15) NULL,
  `rfc` VARCHAR(25) NULL,
  `adress` VARCHAR(140) NULL,
  `city` VARCHAR(140) NULL,
  `zip_code` VARCHAR(10) NOT NULL,
  `sub_customer` TINYINT(1) NULL,
  `costumer_id` INT NULL,
  `update_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`providers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`providers` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`providers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `contact_name` VARCHAR(140) NOT NULL,
  `company` VARCHAR(140) NOT NULL,
  `email` VARCHAR(80) NOT NULL,
  `telephone` VARCHAR(15) NOT NULL,
  `fax` VARCHAR(15) NULL,
  `movil_1` VARCHAR(15) NOT NULL,
  `notes` VARCHAR(250) NULL,
  `active` TINYINT(1) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`materials`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`materials` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`materials` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(55) NOT NULL,
  `code` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`measurement_units`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`measurement_units` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`measurement_units` (
  `id` INT NOT NULL,
  `measurement_unit` VARCHAR(15) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`orders`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`orders` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `costumer_id` INT NOT NULL,
  `branch_id` INT NOT NULL,
  `date_issue` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` FLOAT NOT NULL,
  `measurement_unit_id` INT NOT NULL,
  `total_price` FLOAT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `costumer_idx` (`costumer_id` ASC),
  INDEX `branch_idx` (`branch_id` ASC),
  INDEX `unit_idx` (`measurement_unit_id` ASC),
  CONSTRAINT `costumer`
    FOREIGN KEY (`costumer_id`)
    REFERENCES `armaganza`.`customers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `branch`
    FOREIGN KEY (`branch_id`)
    REFERENCES `armaganza`.`branches` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `unit`
    FOREIGN KEY (`measurement_unit_id`)
    REFERENCES `armaganza`.`measurement_units` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`forms`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`forms` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`forms` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(10) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`detail_orders`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`detail_orders` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`detail_orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_id` INT NOT NULL,
  `form_id` INT NOT NULL,
  `deadline` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `order_idx` (`order_id` ASC),
  INDEX `form_idx` (`form_id` ASC),
  CONSTRAINT `order`
    FOREIGN KEY (`order_id`)
    REFERENCES `armaganza`.`orders` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `form`
    FOREIGN KEY (`form_id`)
    REFERENCES `armaganza`.`forms` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`partitions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`partitions` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`partitions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `detail_order_id` INT NOT NULL,
  `value` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `detail:order_partitions_idx` (`detail_order_id` ASC),
  CONSTRAINT `detail:order_partitions`
    FOREIGN KEY (`detail_order_id`)
    REFERENCES `armaganza`.`detail_orders` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`operations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`operations` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`operations` (
  `id` INT NOT NULL,
  `code` VARCHAR(10) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`detail_form`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`detail_form` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`detail_form` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `form_id` INT NOT NULL,
  `order` INT NOT NULL,
  `operation_id` INT NOT NULL,
  `material_id` INT NOT NULL,
  `value` INT NOT NULL,
  `type` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `form_idx` (`form_id` ASC),
  INDEX `material_idx` (`material_id` ASC),
  INDEX `operation_idx` (`operation_id` ASC),
  CONSTRAINT `detail_form`
    FOREIGN KEY (`form_id`)
    REFERENCES `armaganza`.`forms` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `detail_material`
    FOREIGN KEY (`material_id`)
    REFERENCES `armaganza`.`materials` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `detail_operation`
    FOREIGN KEY (`operation_id`)
    REFERENCES `armaganza`.`operations` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`attributes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`attributes` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`attributes` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name_attribute` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`material_attribute`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`material_attribute` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`material_attribute` (
  `id` INT NOT NULL,
  `material_id` INT NOT NULL,
  `attribute_id` INT NOT NULL,
  `value` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `material_key_idx` (`material_id` ASC),
  INDEX `attribute_idx` (`attribute_id` ASC),
  CONSTRAINT `material_key`
    FOREIGN KEY (`material_id`)
    REFERENCES `armaganza`.`materials` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `attribute`
    FOREIGN KEY (`attribute_id`)
    REFERENCES `armaganza`.`attributes` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `armaganza`.`buys`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`buys` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`buys` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `provider_id` INT NOT NULL,
  `branch_id` INT NOT NULL,
  `quantity` FLOAT NULL,
  `measurement_unit_id` INT NULL,
  `total_price` FLOAT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `providers_idx` (`provider_id` ASC),
  INDEX `branch_idx` (`branch_id` ASC),
  INDEX `unit_idx` (`measurement_unit_id` ASC),
  CONSTRAINT `buys_providers`
    FOREIGN KEY (`provider_id`)
    REFERENCES `armaganza`.`providers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `buys_branch`
    FOREIGN KEY (`branch_id`)
    REFERENCES `armaganza`.`branches` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `buy_unit`
    FOREIGN KEY (`measurement_unit_id`)
    REFERENCES `armaganza`.`measurement_units` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`machines`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`machines` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`machines` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(55) NOT NULL,
  `code` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- -----------------------------------------------------
-- Table `armaganza`.`machine_attribute`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `armaganza`.`machine_attribute` ;

CREATE TABLE IF NOT EXISTS `armaganza`.`machine_attribute` (
  `id` INT NOT NULL,
  `machin_id` INT NOT NULL,
  `attribute_id` INT NOT NULL,
  `value` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `attribute_idx` (`attribute_id` ASC),
  INDEX `machine_key_idx` (`machin_id` ASC),
  CONSTRAINT `machine_key`
    FOREIGN KEY (`machin_id`)
    REFERENCES `armaganza`.`machines` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `attribute0`
    FOREIGN KEY (`attribute_id`)
    REFERENCES `armaganza`.`attributes` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
